/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121partone;
import java.util.regex.Pattern;

public class Login {
    private String storedUsername;
    private String storedPassword;
    private String storedFirstName;
    private String storedLastName;
    private String storedCellPhone;

    // Method to check username format (underscore and max 5 chars)
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            else if (Character.isDigit(c)) hasNumber = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        
        return hasCapital && hasNumber && hasSpecial;
    }

    // Method to check cell phone number using regex
    // Reference: Regular expression for international phone numbers - adapted from
    // https://stackoverflow.com/questions/16703599/regular-expression-for-international-phone-number
    public boolean checkCellPhoneNumber(String phone) {
        // Regex: starts with +, then 1-3 digits for country code, then 6-10 digits
        String regex = "^\\+[0-9]{1,3}[0-9]{6,10}$";
        return phone != null && Pattern.matches(regex, phone);
    }

    // Registration logic
    public String registerUser(String username, String password, String firstName, 
                               String lastName, String cellPhone) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);
        
        if (!validUsername) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!validPassword) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        // Store details for login
        this.storedUsername = username;
        this.storedPassword = password;
        this.storedFirstName = firstName;
        this.storedLastName = lastName;
        this.storedCellPhone = cellPhone;
        
        return "User registered successfully.";
    }

    // Login verification
    public boolean loginUser(String username, String password) {
        return storedUsername != null && storedUsername.equals(username) && 
               storedPassword != null && storedPassword.equals(password);
    }

    // Return login status message
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + storedFirstName + ", " + storedLastName + 
                   " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();
        
        System.out.println("=== Registration ===");
        System.out.print("Enter username (max 5 chars, must contain _): ");
        String username = scanner.nextLine();
        System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter South African cell phone (e.g., +27838968976): ");
        String cellPhone = scanner.nextLine();
        
        String regResult = loginSystem.registerUser(username, password, firstName, lastName, cellPhone);
        System.out.println(regResult);
        
        if (regResult.equals("User registered successfully.")) {
            System.out.println("\n=== Login ===");
            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();
            
            String loginStatus = loginSystem.returnLoginStatus(loginUser, loginPass);
            System.out.println(loginStatus);
        }
        
        scanner.close();
    }
}
import java.util.Scanner;
/**
 *
 * @author donge
 */
public class PROG5121PartOne {

    public static void main(String[] args) {
     import java.util.Scanner;
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();
        
        System.out.println("========================================");
        System.out.println("     USER REGISTRATION SYSTEM");
        System.out.println("========================================");
        
        System.out.print("\nEnter username (max 5 chars, must contain _): ");
        String username = scanner.nextLine();
        
        System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();
        
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        
        System.out.print("Enter South African cell phone (e.g., +27838968976): ");
        String cellPhone = scanner.nextLine();
        
        System.out.println("\n--- Processing Registration ---");
        String regResult = loginSystem.registerUser(username, password, firstName, lastName, cellPhone);
        System.out.println("Result: " + regResult);
        
        if (regResult.equals("User registered successfully.")) {
            System.out.println("\n========================================");
            System.out.println("          USER LOGIN");
            System.out.println("========================================");
            
            System.out.print("\nEnter username: ");
            String loginUser = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();
            
            System.out.println("\n--- Processing Login ---");
            String loginStatus = loginSystem.returnLoginStatus(loginUser, loginPass);
            System.out.println("Result: " + loginStatus);
        }
        
        scanner.close();
        System.out.println("\n========================================");
        System.out.println("Program terminated.");
    }
};
 
